SYNC ENGINE SETUP GUIDE

1. Connect all subsystems to Sync Node
2. Power on main clock
3. Run phase startup scan (expect ACK from all active modules)
4. Monitor for drift via logging system
5. Activate runtime sync loop
6. Check Multi-Node Sync module if applicable

Expect <0.03% timing drift at all times
