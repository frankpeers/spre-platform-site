SPRE AI CORE — SETUP GUIDE

1. Activate Quantum Chip input stream
2. Connect LYRA and ORION AI layers to feedback interface
3. Verify response latency < 10ms
4. Load base personality map into LYRA
5. Set ORION fault boundaries (1.2V threshold)
6. Enable memory archive and log each 100 cycles
