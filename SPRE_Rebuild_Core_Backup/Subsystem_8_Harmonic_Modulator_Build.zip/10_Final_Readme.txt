HARMONIC FIELD MODULATOR — SETUP GUIDE

1. Calibrate terrain sensors (ping cycle: 1s)
2. Load sacred geometry overlay (choose default grid or AI-assisted)
3. Power up modulator and link to SPRE Core
4. Monitor node detection in real time
5. Enable terrain adaptive logic
6. Begin emission sequence tuned to detected geometry

Use with caution in active Earth grid zones.
