COIL 1 — FINAL SETUP INSTRUCTIONS

1. Mount coil inside SPRE input enclosure
2. Align coil facing East at sunrise (optimum lock)
3. Power system to 3.5V
4. Check phase angle lock at 29.5° and 33°
5. Activate signal recording and monitor spike train
6. Proceed to integrate chip for full learning mode
