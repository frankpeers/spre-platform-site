FIELD EMISSION LAYER — FINAL SETUP

1. Connect emission array to Subsystem 3 (signal) and Subsystem 4 (AI model)
2. Verify environmental sensors online
3. Calibrate base field frequency (suggested: 432 Hz harmonic baseline)
4. Set output cap: 5V/m average
5. Enable feedback logging
6. Monitor LYRA/ORION response in tandem with field activation
