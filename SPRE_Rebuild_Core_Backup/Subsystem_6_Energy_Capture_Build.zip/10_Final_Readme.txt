ENERGY CAPTURE SUBSYSTEM — SETUP GUIDE

1. Install capture grid 10cm behind emission layer
2. Activate vector echo monitoring
3. Enable signal logger and drift tracker
4. Link AI emotional tag system (Subsystem 4)
5. Route captured charge to either:
   - Buffer coils
   - Memory archive
   - Modulation banks
6. Confirm pattern archive cycle is active every 100 system ticks
